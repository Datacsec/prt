# Auth backend (FastAPI + SQLAlchemy + JWT)

## Lancer
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    export SECRET_KEY="une-longue-chaine-aleatoire"
    python create_admin.py          # premier admin
    uvicorn app.main:app --reload

Docs interactives : http://127.0.0.1:8000/docs

## Endpoints
- POST /auth/register   inscription (rôle "user")
- POST /auth/login      connexion → token JWT (champ "username" = UID)
- GET  /auth/me         profil de l'utilisateur connecté
- GET  /users           liste des utilisateurs (admin)
- PATCH /users/{uid}    changer rôle / activer-désactiver (admin)
