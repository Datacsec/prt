"""Crée le premier administrateur : python create_admin.py"""
import getpass

from app.database import Base, SessionLocal, engine
from app.models import Role, User
from app.security import hash_password

Base.metadata.create_all(bind=engine)

uid = input("UID : ").strip()
nom = input("Nom : ")
prenom = input("Prénom : ")
password = getpass.getpass("Mot de passe (8 car. min) : ")

with SessionLocal() as db:
    if db.get(User, uid):
        raise SystemExit("Cet UID existe déjà.")
    db.add(User(uid=uid, nom=nom, prenom=prenom,
                password=hash_password(password), role=Role.ADMIN))
    db.commit()
print("Administrateur créé.")
