from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, StringConstraints

from app.models import Role, Status

UID = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=50)]


class UserCreate(BaseModel):
    uid: UID
    nom: str = Field(min_length=1, max_length=100)
    prenom: str = Field(min_length=1, max_length=100)
    password: str = Field(min_length=8, max_length=72)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    uid: str
    nom: str
    prenom: str
    role: Role
    status: Status


class UserAdminUpdate(BaseModel):
    role: Role | None = None
    status: Status | None = None


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
