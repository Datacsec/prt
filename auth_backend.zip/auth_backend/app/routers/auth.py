from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_user
from app.models import Role, Status, User
from app.schemas import Token, UserCreate, UserOut
from app.security import create_access_token, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(data: UserCreate, db: Session = Depends(get_db)):
    if db.get(User, data.uid):
        raise HTTPException(status.HTTP_409_CONFLICT, "Cet UID existe déjà")

    user = User(
        uid=data.uid,
        nom=data.nom,
        prenom=data.prenom,
        password=hash_password(data.password),
        role=Role.USER,  # l'inscription publique crée toujours un simple utilisateur
        status=Status.ACTIF,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=Token)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    # Dans le formulaire OAuth2, le champ "username" contient l'UID.
    user = db.get(User, form.username.strip())
    if user is None or not verify_password(form.password, user.password):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "UID ou mot de passe incorrect")
    if user.status != Status.ACTIF:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Compte désactivé")
    return Token(access_token=create_access_token(user.uid))


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return user
