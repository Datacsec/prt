from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import require_admin
from app.models import User
from app.schemas import UserAdminUpdate, UserOut

router = APIRouter(prefix="/users", tags=["users (admin)"], dependencies=[Depends(require_admin)])


@router.get("", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db)):
    return db.scalars(select(User)).all()


@router.patch("/{uid}", response_model=UserOut)
def update_user(uid: str, data: UserAdminUpdate, db: Session = Depends(get_db)):
    user = db.get(User, uid)
    if user is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Utilisateur introuvable")
    if data.role is not None:
        user.role = data.role
    if data.status is not None:
        user.status = data.status
    db.commit()
    db.refresh(user)
    return user
