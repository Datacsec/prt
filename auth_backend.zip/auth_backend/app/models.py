import enum

from sqlalchemy import Enum, String
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class Role(str, enum.Enum):
    ADMIN = "admin"
    USER = "user"


class Status(str, enum.Enum):
    ACTIF = "ACTIF"
    INACTIF = "INACTIF"


class User(Base):
    __tablename__ = "users"

    uid: Mapped[str] = mapped_column(String(50), primary_key=True)  # UID entreprise, unique
    nom: Mapped[str] = mapped_column(String(100))
    prenom: Mapped[str] = mapped_column(String(100))
    password: Mapped[str] = mapped_column(String(255))  # hash bcrypt, jamais en clair
    role: Mapped[Role] = mapped_column(Enum(Role), default=Role.USER)
    status: Mapped[Status] = mapped_column(Enum(Status), default=Status.ACTIF)
